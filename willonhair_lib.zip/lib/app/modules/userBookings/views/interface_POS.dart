
import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import '../../../../common/ui.dart';
import '../../../../color_constants.dart';
import '../../../../main.dart';
import '../../../routes/app_routes.dart';
import '../../../services/my_auth_service.dart';
import '../../auth/controllers/auth_controller.dart';
import '../../global_widgets/card_widget.dart';
import '../../global_widgets/loading_cards.dart';
import '../../global_widgets/pop_up_widget.dart';
import '../../global_widgets/text_field_widget.dart';
import '../../root/controllers/root_controller.dart';
import '../controllers/bookings_controller.dart';
import '../widgets/bookings_list_item_widget.dart';
import '../widgets/bookings_list_loader_widget.dart';

class InterfacePOSView extends GetView<BookingsController> {

  @override
  Widget build(BuildContext context) {

    Get.lazyPut<RootController>(
          () => RootController(),
    );
    Get.lazyPut(() => AuthController());
    return Scaffold(
        backgroundColor: backgroundColor,
        resizeToAvoidBottomInset: true,
        bottomSheet: buildBottomSheet(context),
        body: RefreshIndicator(
            onRefresh: () async {
              controller.refreshBookings();
            },
            child: SingleChildScrollView(
              child: Obx(() =>
                  Column(
                    children: [
                      Row(
                          children: [
                            Container(
                                padding: EdgeInsets.all(10),
                                width: Get.width/2,
                                height: 70,
                                child: TextFormField(
                                  controller: controller.searchController,
                                  decoration: InputDecoration(
                                      filled: true,
                                      fillColor: backgroundColor,
                                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(5.0)),
                                      hintText: "Rechercher des services",
                                      contentPadding: EdgeInsets.all(10),
                                      hintStyle: TextStyle(fontSize: 12),
                                      suffixIcon: InkWell(
                                          child: Container(
                                            height: 35,
                                            width: 30,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.only(
                                                  topRight: Radius.circular(5),
                                                  bottomRight: Radius.circular(5)
                                              ),
                                              color: Colors.blue,
                                            ),
                                            padding: EdgeInsets.all(5),
                                            child: Center(
                                                child: Icon(!controller.search.value ? Icons.search : Icons.close, color: Palette.background)
                                            ),
                                          ),
                                          onTap: ()async{
                                            if(controller.search.value){
                                              controller.search.value = !controller.search.value;
                                              controller.items.clear();
                                              controller.items.addAll(controller.allServices);
                                              controller.searchController.clear();
                                            }
                                          }
                                      )
                                  ),
                                  onChanged: (value) {
                                    controller.filterSearchResults(value);
                                  },
                                )
                            ),
                            Spacer(),
                            Padding(
                                padding: EdgeInsets.all(10),
                                child: ElevatedButton.icon(
                                    style: ElevatedButton.styleFrom(backgroundColor: employeeInterfaceColor),
                                    onPressed: (){
                                      print(controller.userDto['appointment_ids']);
                                      controller.getAppointments(controller.userDto['appointment_ids']);
                                      showDialog(
                                          context: context,
                                          builder: (BuildContext context) => BookingsListItemWidget()
                                      );
                                    },
                                    icon: Icon(Icons.recommend),
                                    label: Container(
                                        padding: EdgeInsets.all(10),
                                        child: Text("Commandes"))
                                )),
                            SizedBox(width: 10),
                          ]
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                                width: Get.width/2,
                                child: Column(
                                    children: [
                                      Container(
                                        height: 50,
                                        margin: EdgeInsets.all(10),
                                        width: Get.width/2.1,
                                        child: ListView.builder(
                                          itemCount: controller.allCategories.length,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.horizontal,
                                          itemBuilder: (context, index) {
                                            return Obx(() => InkWell(
                                              child: Container(
                                                margin: EdgeInsets.only(right: 10.0, top: 8.0),
                                                padding: EdgeInsets.symmetric(horizontal: 15.0),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(5.0),
                                                  color: controller.selected.value == index ? employeeInterfaceColor : inactive,
                                                ),
                                                child: Center(
                                                  child: Text(controller.allCategories[index]["name"],
                                                    style: TextStyle(
                                                        color: controller.selected.value == index ? CupertinoColors.white : appColor, letterSpacing: 2),
                                                  ),
                                                ),
                                              ),
                                              onTap: ()async{

                                                controller.getServiceByCategory(controller.allCategories[index]['service_ids']);
                                                controller.selected.value = index;
                                                //controller.search.value = false;

                                              },
                                            ));
                                          },
                                        ),
                                      ),
                                      SizedBox(
                                        height: Get.height/3,
                                          width: Get.width/2,
                                          child: Obx(() => Column(
                                            children: [

                                              Expanded(
                                                  child: controller.isLoading.value ?
                                                  GridView.builder(
                                                    itemBuilder: (context, index){
                                                      return buildLoader();
                                                    },
                                                    itemCount: 10,

                                                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                                        crossAxisCount: 2, mainAxisExtent: 190.0, crossAxisSpacing: 15.0, mainAxisSpacing: 15.0),
                                                  ) :
                                                  GridView.builder(
                                                      itemCount: controller.servicesByCategory.length,
                                                      gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                                                          crossAxisCount: 2, mainAxisExtent: 190.0, crossAxisSpacing: 15.0, mainAxisSpacing: 15.0),
                                                      itemBuilder: (context, index) {
                                                        //articles?.sort((a, b) => b.date.compareTo(a.date));

                                                        return InkWell(
                                                            onTap: ()async{

                                                            },
                                                            child: Container(
                                                                padding: EdgeInsets.only(top: 5, bottom: 5),
                                                                decoration: BoxDecoration(
                                                                  borderRadius: BorderRadius.circular(10),
                                                                  color: primaryColor.withOpacity(0.3),
                                                                ),
                                                                child: Column(
                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                  children: [
                                                                    FadeInImage(
                                                                      width: 130,
                                                                      height: 130,
                                                                      fit: BoxFit.cover,
                                                                      image: NetworkImage('${Domain.serverPort}/image/appointment.product/${controller.servicesByCategory[index]['id']}/image_1920?unique=true&file_response=true', headers: Domain.getTokenHeaders()),
                                                                      placeholder: AssetImage(
                                                                          "assets/img/loading.gif"),
                                                                      imageErrorBuilder:
                                                                          (context, error, stackTrace) {
                                                                        return Image.asset(
                                                                            'assets/img/photo_2022-11-25_01-12-07.jpg',
                                                                            width: 130,
                                                                            height: 130,
                                                                            fit: BoxFit.fitWidth);
                                                                      },
                                                                    ),
                                                                    Text(controller.servicesByCategory[index]["name"].split(">").first),
                                                                    Text("${controller.servicesByCategory[index]["product_price"]} EUR")
                                                                  ]
                                                                )
                                                            )
                                                        );
                                                      }
                                                  )
                                              )
                                            ],
                                          )
                                          )
                                      )
                                    ]
                                )
                            ),
                            SizedBox(
                                width: Get.width/2,
                                height: Get.height - Get.height/4,
                                child: Card(
                                  child: Padding(
                                      padding: EdgeInsets.all(10),
                                  child: Column(
                                      children: [
                                        Obx(() => Row(
                                            children: [
                                              RichText(
                                                  text: TextSpan(
                                                      children: [
                                                        TextSpan(text: "Détails de ", style: TextStyle(fontSize: 20, color: appColor)),
                                                        TextSpan(text: controller.selectedAppointment['name']
                                                            , style: TextStyle(fontSize: 20, color: appColor, fontWeight: FontWeight.bold))
                                                      ]
                                                  )
                                              ),
                                              Spacer(),
                                              if(controller.selectedAppointment['name'] == null)
                                                SpinKitFadingCircle(color: employeeInterfaceColor, size: 30),
                                              SizedBox(width: 10)
                                            ]
                                        )),
                                      ]
                                  )
                                  )
                                )
                            )
                          ]
                      )
                    ],
                  )
              )
            )
        )
    );
  }

  Widget buildBottomSheet(BuildContext context){

    //var userDto = controller.userDto;
    var width = Get.width/3;
    double height = 60;

    return Container(
      width: Get.width,
      height: Get.height/4,
      color: bgColor,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Row(
            children: [
              Container(
                alignment: Alignment.center,
                width: MediaQuery.of(context).size.width / 3,
                child: RichText(
                    text: TextSpan(
                        children: [
                          TextSpan(text: "Client Bonus: ", style: TextStyle(color: Colors.white, letterSpacing: 1, fontSize: 20)),
                          TextSpan(text: "0.", style: TextStyle(color: Colors.white, letterSpacing: 2, fontSize: 25, fontWeight: FontWeight.bold))
                        ]
                    )
                ),
              ),
              Spacer(),
              Container(
                alignment: Alignment.center,
                width: MediaQuery.of(context).size.width / 3,
                child: RichText(
                    text: TextSpan(
                        children: [
                          TextSpan(text: "Total: ", style: TextStyle(color: Colors.white, letterSpacing: 1, fontSize: 20)),
                          TextSpan(text: "234 EUR", style: TextStyle(color: validateColor, letterSpacing: 2, fontSize: 25, fontWeight: FontWeight.bold))
                        ]
                    )
                ),
              ),
            ],
          ),
          Divider(color: Colors.white),
          //SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              InkWell(
                  onTap: (){
                    /*Navigator.of(context).push( MaterialPageRoute<Null>(
                                          builder: (BuildContext context) {
                                            return SelectClient();
                                          },
                                          fullscreenDialog: true));*/
                  },
                  child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.blue, width: 2),
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                      ),
                      width: width,
                      height: height,
                      padding: EdgeInsets.only(left: 5, right: 5),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                    image: AssetImage("assets/img/man.png"),
                                  )
                              )
                            ),
                            SizedBox(width: 10),
                            Obx(() => Expanded(
                                child: Text(controller.selectedAppointment['partner_id'] != null ? controller.selectedAppointment['partner_id'][1] : "ANONYME", style: TextStyle(color: Colors.white, letterSpacing: 2, fontSize: 20), overflow: TextOverflow.ellipsis,
                                )
                            ))
                          ]
                      )
                  )
              ),
              InkWell(
                onTap: (){
                  /*if(appointmentId != 0){
                    showDialog(
                        context: context,
                        builder: (BuildContext context) => Remise());
                  }*/
                },
                child: Obx(() => Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: controller.selectedAppointment['partner_id'] != null ? Colors.blue : inactive, width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(5)),
                    ),
                    width: width,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    height: height,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            width: 30,
                            height: 30,
                            margin: EdgeInsets.only(left: 10, right: 10),
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage("assets/img/data-transfer.png"),
                                )
                            ),
                          ),
                          Text("TRANSFERER", style: TextStyle(color: controller.selectedAppointment['partner_id'] != null ? Colors.white : inactive, letterSpacing: 2, fontSize: 20)
                          ),
                        ],
                      ),
                    )
                )
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              InkWell(
                onTap: (){
                  /*if(appointmentId != 0){
                    showDialog(
                        context: context,
                        builder: (BuildContext context) => Remise());
                  }*/
                },
                child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: inactive, width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(5)),
                    ),
                    width: width,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    height: height,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            width: 30,
                            height: 30,
                            margin: EdgeInsets.only(left: 10, right: 10),
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage("assets/img/offer.png"),
                                )
                            )
                          ),
                          Text("REMISE", style: TextStyle(color: inactive, letterSpacing: 2, fontSize: 20)
                          ),
                        ],
                      ),
                    )
                ),
              ),
              InkWell(
                  onTap: ()async{
                    /*print("bonus: ${userDto['client_bonus']}");
                  if(userDto != null && userDto['client_bonus'] > 0){
                    List list = [];
                    int currentItem = 0;
                    setState(() {
                      waitingBonuses = true;
                    });
                    final data = await getBonuses();
                    for(var i in data){
                      if(i['discount_management'] == "bonus"){
                        setState(() {
                          list.add(i);
                          bonuses = list;
                        });
                      }
                    }
                    showDialog(
                        context: context,
                        builder: (BuildContext context) => FadeIn(delay: 200,
                            child: AlertDialog(
                                contentPadding: EdgeInsets.all(10),
                                backgroundColor: background,
                                content: Container(
                                  height: MediaQuery.of(context).size.height /3,
                                  width: MediaQuery.of(context).size.width /2,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Text("Choisissez un bonus a utiliser", style: TextStyle(fontSize: 20)),
                                      SizedBox(height: 30),
                                      Expanded(
                                          child: GridView.builder(
                                              itemCount: bonuses.length,
                                              gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                                                  crossAxisCount: Responsive.isDesktop(context) ? 3 : 2, mainAxisExtent: 150.0, crossAxisSpacing: 15.0, mainAxisSpacing: 15.0),
                                              itemBuilder: (context, index) {
                                                //articles?.sort((a, b) => b.date.compareTo(a.date));
                                                return InkWell(
                                                    onTap: ()async{
                                                      setState((){
                                                        selectedBonus = !selectedBonus;
                                                        currentItem = index;
                                                        bonusId = bonuses[index]('id');
                                                        bonusName = bonuses[index]('name');
                                                      });
                                                      print(bonuses[index]('id'));
                                                    },
                                                    child: Container(
                                                        margin: EdgeInsets.only(left: 10, right: 10),
                                                        padding: EdgeInsets.only(top: 10, bottom: 10),
                                                        decoration: BoxDecoration(
                                                            borderRadius: BorderRadius.circular(15),
                                                            color: Colors.white,
                                                            border: currentItem == index && selectedBonus ? Border.all(width: 3, color: blue) : null
                                                        ),
                                                        child: Column(
                                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                          children: [
                                                            Container(
                                                                width: 130,
                                                                height: 100,
                                                                decoration: BoxDecoration(
                                                                  image: bonuses[index]['list_price'] == -10 ? DecorationImage(image: AssetImage('assets/images/photo_2023-01-12_17-47-37.png')) :
                                                                  bonuses[index]['list_price'] == -13 ? DecorationImage(image: AssetImage('assets/images/photo_2023-01-12_17-47-32.png')) :
                                                                  DecorationImage(image: AssetImage('assets/images/photo_2023-01-12_17-47-41.png')),
                                                                )
                                                            ),
                                                            Text(bonuses[index]["name"])
                                                          ],
                                                        )
                                                    )
                                                );
                                              }
                                          )
                                      ),
                                      //bonuses[index]["id"]
                                      SizedBox(height: 10),
                                      Align(
                                        alignment: Alignment.bottomRight,
                                        child: InkWell(
                                          onTap: (){
                                            setState(() {
                                              isClicked = true;
                                            });
                                            var data = json.encode({
                                              "discount_type": "bonus"
                                            });
                                            useMyBonus(data);
                                          },
                                          child: Container(
                                              width: 150,
                                              height: 40,
                                              decoration: BoxDecoration(
                                                color: validateColor,
                                                borderRadius: BorderRadius.all(Radius.circular(5)),
                                              ),
                                              child: Center(
                                                child: isClicked ? SizedBox(
                                                    width: 16,
                                                    height: 16,
                                                    child: CircularProgressIndicator(
                                                      color: Colors.white,
                                                      strokeWidth: 1.5,
                                                    )) : Text("OK", style: TextStyle(color: Colors.white, letterSpacing: 2, fontSize: 15)),)
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                            )
                        )
                    );
                  }else{
                    final snackBar = SnackBar(
                      elevation: 0,
                      behavior: SnackBarBehavior.floating,
                      backgroundColor: Colors.transparent,
                      content: AwesomeSnackbarContent(
                        title: 'Info',
                        message:
                        "Ce client n'a pas de bonus!",
                        contentType: ContentType.warning,
                      ),
                    );
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(snackBar);
                  }*/
                  },
                  child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.blue, width: 2),
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                      ),
                      width: width,
                      padding: EdgeInsets.only(left: 5, right: 5),
                      height: height,
                      child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Container(
                                        width: 30,
                                        height: 30,
                                        margin: EdgeInsets.only(left: 10, right: 10),
                                        decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage("assets/images/gift.png"),
                                            )
                                        ),
                                      ),
                                      Text("Loading...", style: TextStyle(color: inactive))
                                    ]
                                )
                              ]
                          )
                      )
                  )
              ),
            ],
          ),
          InkWell(
            onTap: (){
              /*showDialog(
                  context: context,
                  builder: (_){
                    return showContext(context);
                  });*/
            },
            child: Container(
              width: MediaQuery.of(context).size.width / 1.2,
              height: height,
              margin: EdgeInsets.only(left: 10, right: 10),
              decoration: BoxDecoration(
                color: inactive,
                borderRadius: BorderRadius.all(Radius.circular(5)),
              ),
              child: Center(child: Text("TERMINER", style: TextStyle(color: Colors.white, letterSpacing: 2, fontSize: 20))),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildLoader() {
    return ClipRRect(
      borderRadius: BorderRadius.all(Radius.circular(10)),
      child: Image.asset(
        'assets/img/loading.gif',
        fit: BoxFit.cover,
        width: 200,
        height: 100,
      ),
    );
  }
}
