import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../../../../color_constants.dart';
import '../../../providers/odoo_provider.dart';
import '../../../services/my_auth_service.dart';
import '../../e_service/widgets/e_service_title_bar_widget.dart';
import '../../travel_inspect/controllers/travel_inspect_controller.dart';
import '../../userBookings/controllers/bookings_controller.dart';

class ShippingDetails extends GetView<BookingsController> {

  @override
  Widget build(BuildContext context) {
    final box = GetStorage();
    Get.lazyPut<MyAuthService>(
          () => MyAuthService(),
    );
    Get.lazyPut<OdooApiClient>(
          () => OdooApiClient(),
    );
    Get.lazyPut(()=>BookingsController());
    Get.lazyPut<TravelInspectController>(
          () => TravelInspectController(),
    );
    return Obx(() {

      return Scaffold(
        body: CustomScrollView(
          primary: true,
          shrinkWrap: false,
          slivers: <Widget>[
            SliverAppBar(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              expandedHeight: 310,
              elevation: 0,
              floating: true,
              iconTheme: IconThemeData(color: Theme.of(context).primaryColor),
              centerTitle: true,
              automaticallyImplyLeading: false,
              leading: new IconButton(
                icon: Container(
                    decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
                      BoxShadow(
                        color: Get.theme.primaryColor.withOpacity(0.5),
                        blurRadius: 20,
                      ),
                    ]),
                    child: CircleAvatar(
                        radius: 20,
                        backgroundColor: Colors.white,
                        child: FaIcon(FontAwesomeIcons.arrowLeft, color: buttonColor)
                    )
                ),
                onPressed: () => {
                  Get.back()
                }
              ),
              bottom: buildEServiceTitleBarWidget(context),
              flexibleSpace: FlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                background: Obx(() {

                  return Stack(
                    alignment: AlignmentDirectional.bottomCenter,
                    children: <Widget>[

                      buildCarouselBullets(context)
                    ],
                  );
                }),
              ).marginOnly(bottom: 50),
            ),
            // WelcomeWidget(),
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                ],
              ),
            ),
          ],
        ),
      );
    });
  }

  Container buildCarouselBullets(BuildContext context) {
    double width = MediaQuery.of(context).size.width/1.2;
    return Container(
        margin: EdgeInsets.symmetric(vertical: 100, horizontal: 20),
        child: Container(
            alignment: Alignment.center,
            width: width,
            height: 100,
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.7),
                borderRadius: BorderRadius.all(Radius.circular(10))
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

              ]
            )
        )
    );
  }

  EServiceTitleBarWidget buildEServiceTitleBarWidget(BuildContext context) {
    double width = MediaQuery.of(context).size.width/2.8;
    return EServiceTitleBarWidget(
      title: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [

            ],
          ),
        ],
      ),
    );
  }

  Widget buildBottomWidget(BuildContext context) {

    Get.lazyPut(()=>TravelInspectController());

    return Container(
        padding: EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Get.theme.primaryColor,
          borderRadius: BorderRadius.all(Radius.circular(20)),
          boxShadow: [
            BoxShadow(color: Get.theme.focusColor.withOpacity(0.1), blurRadius: 10, offset: Offset(0, -5)),
          ],
        ),
        child: SizedBox()
    );
  }

  Widget buildTravellerView(BuildContext context){
    return SizedBox();
  }

  Widget buildLoader() {
    return Container(
        width: 100,
        height: 100,
        child: ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          child: Image.asset(
            'assets/img/loading.gif',
            fit: BoxFit.cover,
            width: double.infinity,
            height: 100,
          ),
        )
    );
  }
}
