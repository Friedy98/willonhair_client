import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../color_constants.dart';
import '../../../../common/ui.dart';
import '../../../../main.dart';
import 'package:http/http.dart' as http;
import '../../../providers/odoo_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/my_auth_service.dart';
import '../../auth/controllers/auth_controller.dart';
import '../../home/controllers/home_controller.dart';
import '../../travel_inspect/controllers/travel_inspect_controller.dart';

class BookingsController extends GetxController {

  var predict1 = false.obs;
  var errorCity1 = false.obs;
  TextEditingController searchController = TextEditingController();
  var street = "".obs;
  var cityId = 0.obs;
  var countries = [].obs;
  var userDto = {}.obs;
  var search = false.obs;
  var price = 0.0.obs;
  var employeeDto = {}.obs;
  var appointmentDto = {}.obs;
  var paymentLink = "".obs;
  var items = [].obs;
  var sample = [];
  var isLoading = true.obs;
  var allServices = [].obs;
  var appointments = [].obs;
  var allCategories = [].obs;
  var servicesByCategory = [].obs;
  var selectedAppointment = {}.obs;
  var selected = 0.obs;
  var loadingAppointments = true.obs;
  var treated = false.obs;
  var showBackButton = false.obs;
  var firstDate = DateFormat("dd, MMMM", "fr_CA").format(DateTime.now()).toString().obs;
  var lastDate = DateFormat("dd, MMMM", "fr_CA").format(DateTime.now().add(Duration(days: 5))).toString().obs;
  TextEditingController dateController = TextEditingController();

  selectDate()async{

    final DateTimeRange result = await showDateRangePicker(
      context: Get.context,
      locale: Locale("fr", "FR"),
      firstDate: DateTime(2000),
      lastDate: DateTime(2030, 12, 31).add(Duration(days: 30)),
      currentDate: DateTime.now(),
      saveText: 'Confirmer',
    );

    List<String> dates = result.toString().split(" - ");
    String date1 = dates[0];
    String date2 = dates[1];
    DateTime startDate = DateTime.parse(date1);
    DateTime endDate = DateTime.parse(date2);

    firstDate.value = DateFormat("dd, MMMM yyyy", "fr_CA").format(startDate).toString();
    lastDate.value = DateFormat("dd, MMMM yyyy", "fr_CA").format(endDate).toString();
    dateController.text = firstDate.value + " - " + lastDate.value;

    List list = [];
    List finalList = [];
    final daysToGenerate = endDate.add(Duration(days: 1)).difference(startDate).inDays;
    finalList = List.generate(daysToGenerate, (i) => DateTime(startDate.year, startDate.month, startDate.day + (i)));

    for(var i=0; i<finalList.length; i++){
      String formatted2 = DateFormat("yyyy-MM-dd").format(finalList[i]).toString();
      print("interval date: $formatted2");
      for(var a=0; a<appointments.length; a++){
        String formatted = DateFormat("yyyy-MM-dd").format(DateTime.parse(appointments[a]['datetime_start'])).toString();
        if(formatted == formatted2){
          list.add(appointments[a]);
        }
      }
    }
    appointments.value = list;
  }

  BookingsController() {
    Get.lazyPut<OdooApiClient>(
          () => OdooApiClient(),
    );
    Get.lazyPut<TravelInspectController>(
          () => TravelInspectController(),
    );
  }

  @override
  void onInit() {
    super.onInit();
    Get.lazyPut<OdooApiClient>(
          () => OdooApiClient(),
    );
    initValues();
  }

  @override
  void onReady(){
    initValues();
    super.onReady();
  }

  initValues()async{
    isLoading.value = true;
    loadingAppointments.value = true;
    Get.lazyPut<AuthController>(
          () => AuthController(),
    );
    var data = await getCategories();
    allCategories.value = data;
    final box = GetStorage();
    var userdata = box.read("userData");
    userDto.value = userdata;
    print(userDto);

    if(Get.find<AuthController>().isEmployee.value){
      getAppointments(userDto['appointment_ids']);
    }else{
      await getCurrentUser(userDto['partner_id']);
    }
  }

  refreshBookings()async{
    initValues();
  }

  void filterSearchResults(String query) {

    List dummySearchList = [];
    dummySearchList.addAll(sample);
    if(query.isNotEmpty) {
      List dummyListData = [];
      dummySearchList.forEach((item) {
        if(item['partner_id'][1].toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      items.value = dummyListData;
      servicesByCategory = items;
      return;
    } else {
      items.clear();
      items.value = sample;
    }
  }

  Future getCategories()async{
    var headers = {
      'Accept': 'application/json',
      'Authorization': Domain.authorization
    };
    var request = http.Request('GET', Uri.parse('${Domain.serverPort}/search_read/business.resource.type'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      final data = await response.stream.bytesToString();
      getServiceByCategory(json.decode(data)[0]['service_ids']);
      return json.decode(data);
    }
    else {
      print(response.reasonPhrase);
    }
  }

  getServiceByCategory(var values)async{
    var ids = values.join(",");
    print(ids);
    var headers = {
      'Cookie': 'frontend_lang=fr_FR; session_id=bb097a3095a1d281f01592bd331b9c8f9c8631bd; visitor_uuid=fcef730c94854dfc991dcde26c242a3e'
    };
    var request = http.Request('GET', Uri.parse('https://willonhair.shintheo.com/get_products?ids=$ids'));
    request.body = '''{\n    "jsonrpc": "2.0"\n}''';
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      isLoading.value = false;
      servicesByCategory.value = json.decode(data);
    }
    else {
      print(response.reasonPhrase);
    }
  }

  Future getCurrentUser(var id)async{
    var headers = {
      'Accept': 'application/json',
      'Authorization': Domain.authorization,
    };
    var request = http.Request('GET', Uri.parse('${Domain.serverPort}/read/res.partner?ids=$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      isLoading.value = false;
      var result = json.decode(data)[0];
      getAppointments(result['appointment_ids']);
    }
    else {
      print(response.reasonPhrase);
    }
  }

  getAppointments(var ids)async{

    var headers = {
      'Accept': 'application/json',
      'Authorization': Domain.authorization
    };
    var request = http.Request('GET', Uri.parse('${Domain.serverPort}/read/business.appointment?ids=$ids'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      items.value = json.decode(data);
      sample = json.decode(data);
      isLoading.value = false;
      return json.decode(data);
    }
    else {
      print(response.reasonPhrase);
    }
  }

  uploadProfileImage(File file, int id) async {
    if (Get.find<MyAuthService>().myUser.value.email==null) {
      throw new Exception("You don't have the permission to access to this area!".tr + "[ uploadImage() ]");
    }

    var headers = {
      'Accept': 'application/json',
      'Authorization': Domain.authorization,
      'Content-Type': 'multipart/form-data',
      'Cookie': 'session_id=a5b5f221b0eca50ae954ad4923fead1063097951'
    };
    var request = http.MultipartRequest('POST', Uri.parse('${Domain.serverPort}/upload/res.partner/$id/image_1920'));
    request.files.add(await http.MultipartFile.fromPath('ufile', file.path));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();


    if (response.statusCode == 200) {
      await response.stream.bytesToString();
      //var user = await getUser();
      //var uuid =user.image ;

      //return uuid;
    }
    else {
      print(response.reasonPhrase);
    }
  }

  launchURL(var link) async {
    if(link.toString() != "false"){
      ScaffoldMessenger.of(Get.context).showSnackBar(SnackBar(
        content: Text(link.toString()),
        backgroundColor: validateColor.withOpacity(0.4),
        margin: EdgeInsets.only(
            bottom: Get.height - 160,
            left: 10,
            right: 10),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ));

      final Uri url = Uri.parse(link);
      if (!await launchUrl(url)) {
        throw Exception('Could not launch $url');
      }
    }else{
      ScaffoldMessenger.of(Get.context).showSnackBar(SnackBar(
        content: Text("Error occurred...[$link]"),
        margin: EdgeInsets.only(
            bottom: Get.height - 160,
            left: 10,
            right: 10),
        behavior: SnackBarBehavior.floating,
        backgroundColor: specialColor.withOpacity(0.4),
        duration: Duration(seconds: 2),
      ));
    }
  }

  @override
  void onClose() {
    //chatTextController.dispose();
  }

  getServiceDto(var item, var appointment, bool client) async{

    var headers = {
      'Cookie': 'frontend_lang=fr_FR; session_id=bb097a3095a1d281f01592bd331b9c8f9c8631bd; visitor_uuid=fcef730c94854dfc991dcde26c242a3e'
    };
    var request = http.Request('GET', Uri.parse('https://willonhair.shintheo.com/get_products?ids=$item'));
    request.body = '''{\n    "jsonrpc": "2.0"\n}''';
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      Navigator.pop(Get.context);
      var data = await response.stream.bytesToString();
      var service = json.decode(data)[0];
      var duration = service["appointment_duration"]*60;
      showDialog(
          context: Get.context,
          builder: (_){
            return AlertDialog(
              title: Text(appointment['name']),
              content: SizedBox(
                height: 100,
                width: Get.width,
                child: Column(
                  children: [
                    ListTile(
                      leading: ClipRRect(
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                          child: FadeInImage(
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                            image: NetworkImage("${Domain.serverPort}/image/appointment.product/${service['id']}/image_1920?unique=true&file_response=true",
                                headers: Domain.getTokenHeaders()),
                            placeholder: AssetImage(
                                "assets/img/loading.gif"),
                            imageErrorBuilder:
                                (context, error, stackTrace) {
                              return Image.asset(
                                  "assets/img/photo_2022-11-25_01-12-07.jpg",
                                  width: 60,
                                  height: 60,
                                  fit: BoxFit.fitWidth);
                            },
                          )
                      ),
                      title: Text(service['name'].split(">").first + "\n"+ service["product_price"].toString()+" €",
                          style: Get.textTheme.headline2),
                      subtitle: Text(duration.toString()+" minutes", style: Get.textTheme.headline2),
                    )
                  ],
                ),
              ),
              actions: [
                if(appointment['state'] == "reserved" || client)
                Align(
                  alignment: Alignment.bottomRight,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: client ? interfaceColor : employeeInterfaceColor),
                    child: Text(client ? "Annuler le rendez-vous" : "Traiter le rendez-vous"),
                    onPressed: ()=>{

                      Get.lazyPut(() => HomeController()),

                      Navigator.pop(Get.context),
                      if(client){
                        showDialog(
                            context: Get.context,
                            builder: (_){
                              return AlertDialog(
                                title: Text("Annuler le rendez-vous"),
                                content: Text('Voulez vous vraiment annuler votre rendez-vous?', style: Get.textTheme.headline4),
                                actions: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      TextButton(
                                          onPressed: ()=> Navigator.pop(Get.context),
                                          child: Text('Retour')
                                      ),
                                      SizedBox(width: 10),
                                      TextButton(
                                          onPressed: ()=> cancelBooking(appointment['id']),
                                          child: Text('Annuler le rendez-vous', style: Get.textTheme.headline2)
                                      ),
                                    ],
                                  )
                                ],
                              );
                            }
                        )
                      }else{

                        selectedAppointment.value = appointment,
                        refreshBookings(),
                        Get.find<HomeController>().currentPage.value = 2

                      }
                    },
                  ),
                )
              ],
            );
          });
    }
    else {
      print(response.reasonPhrase);
    }
  }

  cancelBooking(int id) async{
    Navigator.pop(Get.context);

    showDialog(
        context: Get.context,
        builder: (_){
          return SpinKitFadingCircle(color: Colors.white, size: 50);
        });

    var headers = {
      'Accept': 'application/json',
      'Authorization': Domain.authorization
    };
    var request = http.Request('POST', Uri.parse('${Domain.serverPort}/call/business.appointment/action_cancel?ids=$id'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var data = await response.stream.bytesToString();
      Navigator.pop(Get.context);
      refreshBookings();
      Get.showSnackbar(Ui.SuccessSnackBar(message: "Votre rendez-vous à été annulé avec succès".tr ));
    }
    else {
      var data = await response.stream.bytesToString();
      Get.showSnackbar(Ui.ErrorSnackBar(message: json.decode(data)['message'] ));
      print(response.reasonPhrase);
    }
  }
}
